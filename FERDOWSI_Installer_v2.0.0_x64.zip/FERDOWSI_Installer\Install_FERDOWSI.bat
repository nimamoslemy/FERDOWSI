@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File -ErrorAction SilentlyContinue"
start "" "%~dp0FERDOWSI_Setup_v2.0.0.exe"
